package com.hiynn.spring.mybatis.plus.lxp.mapper;

import com.hiynn.spring.mybatis.plus.lxp.entity.DataOperateLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 操作记录 Mapper 接口
 * </p>
 *
 * @author joe
 * @since 2019-10-21
 */
public interface DataOperateLogMapper extends BaseMapper<DataOperateLog> {

}
