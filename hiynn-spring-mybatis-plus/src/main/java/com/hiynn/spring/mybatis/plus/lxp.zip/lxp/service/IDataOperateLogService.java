package com.hiynn.spring.mybatis.plus.lxp.service;

import com.hiynn.spring.mybatis.plus.lxp.entity.DataOperateLog;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 操作记录 服务类
 * </p>
 *
 * @author joe
 * @since 2019-10-21
 */
public interface IDataOperateLogService extends IService<DataOperateLog> {

}
