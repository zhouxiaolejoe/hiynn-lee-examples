package com.hiynn.spring.mybatis.plus.lxp.mapper;

import com.hiynn.spring.mybatis.plus.lxp.entity.DataResourceDetail;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author joe
 * @since 2019-10-21
 */
public interface DataResourceDetailMapper extends BaseMapper<DataResourceDetail> {

}
