package com.hiynn.micro.service.consumer;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServiceConsumerApplicationTests {

    @Test
    void contextLoads() {
    }

}
