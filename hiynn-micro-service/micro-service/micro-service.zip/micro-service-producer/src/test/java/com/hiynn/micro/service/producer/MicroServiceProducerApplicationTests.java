package com.hiynn.micro.service.producer;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServiceProducerApplicationTests {

    @Test
    void contextLoads() {
    }

}
